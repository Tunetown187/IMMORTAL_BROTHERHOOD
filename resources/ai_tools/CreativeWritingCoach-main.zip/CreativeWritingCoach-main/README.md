# CreativeWritingCoach
Finetune a GPT-3 model to provide copy editing (prose) feedback and critique
