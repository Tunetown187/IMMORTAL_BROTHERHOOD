# generative-art-node
Create generative art by using the canvas api and node js
