interface Window {
  showDirectoryPicker(): Promise<FileSystemDirectoryHandle>;
}
